module export_tool

go 1.20

require (
    github.com/snowflakedb/gosnowflake v1.6.6
    gopkg.in/ini.v1 v1.66.4
)
