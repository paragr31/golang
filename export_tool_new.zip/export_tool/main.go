package main

import (
    "context"
    "fmt"
    "log"
    "os"
    "path/filepath"
    "strings"

    "export_tool/pkg/config"
    "export_tool/pkg/snowflake"
    "export_tool/pkg/sybaseiq"
    "export_tool/pkg/writer"
    "export_tool/pkg/xmlmeta"
	"github.com/sirupsen/logrus"

)

func main() {
    cfg, err := config.LoadConfig("config.cfg")
    if err != nil {
        log.Fatalf("load config: %v", err)
    }
	
	// create logger (both file + console)
    logger := logrus.New()
    logFile := cfg.Constants.LogFile
    file, err := os.OpenFile(logFile, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0644)
    if err == nil {
        mw := io.MultiWriter(os.Stdout, file)
        logger.SetOutput(mw)
    } else {
        logger.SetOutput(os.Stdout)
    }
    logger.SetFormatter(&logrus.TextFormatter{FullTimestamp: true})
	
	config.SetLogger(logger)
    snowflake.SetLogger(logger)
    sybaseiq.SetLogger(logger)
    writer.SetLogger(logger)
    xmlmeta.SetLogger(logger)
	
    // connect sybase
    sydb, err := sybaseiq.Connect(cfg.Sybase.Driver, cfg.Sybase.DSN)
    if err != nil {
        logger.Fatalf("connect sybase: %v", err)
    }
    defer sydb.Close()

    // connect snowflake
    priv, err := snowflake.LoadPrivateKey(cfg.Snowflake.PrivateKey)
    if err != nil {
        logger.Fatalf("load private key: %v", err)
    }
    sfdb, err := snowflake.Connect(cfg.Snowflake.Account, cfg.Snowflake.User, cfg.Snowflake.Role, cfg.Snowflake.Warehouse, cfg.Snowflake.Database, priv)
    if err != nil {
        logger.Fatalf("connect snowflake: %v", err)
    }
    defer sfdb.Close()

    // ensure data dir
    _ = os.MkdirAll(cfg.Static.DataFilePath, 0o755)

    tables := cfg.Static.Tables
    for _, t := range tables {
        // t like "SCHEMA.TABLE"
        parts := strings.SplitN(t, ".", 2)
        schema := parts[0]
        table := parts[1]

        logger.Printf("Processing %s.%s", schema, table)

        cols, err := sybaseiq.GetTableColumns(sydb, schema, table)
        if err != nil {
            logger.Printf("get columns: %v", err)
            continue
        }
        schemaFile := filepath.Join(cfg.Static.SchemaWritingDir, fmt.Sprintf("%s_%s.schema", schema, table))
        _ = sybaseiq.WriteSchemaFile(schemaFile, cols)

        selectList := sybaseiq.BuildSnowflakeSelect(cols, cfg)
        query := fmt.Sprintf("SELECT %s FROM \"%s\".\"%s\"", strings.Join(selectList, ", "), schema, table)

        outBase := fmt.Sprintf("%s_%s", schema, table)
        bcpPath := filepath.Join(cfg.Static.DataFilePath, outBase+".bcp")
        gzPath := bcpPath + ".gz"

        rows, sha, size, err := writer.StreamQueryToGzip(context.Background(), sfdb, query, gzPath, cfg.Static.FieldSeparatorBinary, cfg.Static.LineSeparatorBinary, cfg.Output.NullString)
        if err != nil {
            logger.Printf("stream error: %v", err)
            continue
        }

        meta := xmlmeta.XMLMeta{
            FileName:       filepath.Base(gzPath),
            SHA256:         sha,
            FileSize:       size,
            Rows:           rows,
            GzipMembers:    1,
            SchemaFilePath: schemaFile,
            ReconFilePath:  filepath.Join(cfg.Static.ReconWritingDir, outBase+".recon"),
            RecycleDate:    cfg.Static.RecycleDate,
            RangeStart:     cfg.Static.RangeStart,
            RangeEnd:       cfg.Static.RangeEnd,
        }
        xmlOut := filepath.Join(cfg.Static.DataFilePath, outBase+".xml")
        _ = xmlmeta.Render(cfg.Static.XMLTemplatePath, xmlOut, meta)

        // move to landing
        _ = writer.MoveFile(gzPath, filepath.Join(cfg.Static.LandingFilePath, filepath.Base(gzPath)))
        _ = writer.MoveFile(xmlOut, filepath.Join(cfg.Static.LandingFilePath, filepath.Base(xmlOut)))

        logger.Printf("Finished %s.%s rows=%d size=%d sha=%s", schema, table, rows, size, sha)
    }

    // create tar.gz of data folder
    tarPath := filepath.Join(cfg.Static.DataFilePath, "export.tar.gz")
    sha, size, err := writer.CreateTarGz(cfg.Static.DataFilePath, tarPath)
    if err != nil {
        logger.Fatalf("create tar.gz: %v", err)
    }
    logger.Printf("Created tar.gz %s size=%d sha=%s", tarPath, size, sha)

    // move tar to landing
    _ = writer.MoveFile(tarPath, filepath.Join(cfg.Static.LandingFilePath, filepath.Base(tarPath)))

    logger.Println("Done")
}
