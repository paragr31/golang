package config

import (
    "fmt"
    "gopkg.in/ini.v1"
    "path/filepath"
    "strings"
	"github.com/sirupsen/logrus"
)

var log *logrus.Logger

func SetLogger(l *logrus.Logger) {
    log = l
}

type SnowflakeConfig struct {
    Account    string
    User       string
    PrivateKey string
    Role       string
    Warehouse  string
    Database   string
    Schema     string
}

type SybaseConfig struct {
    Driver string
    DSN    string
}

type StaticConfig struct {
    Tables               []string
    RecycleDate          string
    RangeStart           string
    RangeEnd             string
    DataFilePath         string
    LandingFilePath      string
    LogPath              string
    SchemaWritingDir     string
    ReconWritingDir      string
    XMLTemplatePath      string
    FieldSeparatorBinary string
    LineSeparatorBinary  string
}

type OutputConfig struct {
    NullString         string
    EscapeSequence     string
    NewlineReplacement string
    BooleanAsInt       bool
    DateFormat         string
    TimestampFormat    string
    ChunkRows          int64
}

type ConstantConfig struct {
    LogFileName string
}

type AppConfig struct {
    Snowflake SnowflakeConfig
    Sybase    SybaseConfig
    Static    StaticConfig
    Output    OutputConfig
    Constant  ConstantConfig
}

func LoadConfig(path string) (*AppConfig, error) {
    iniCfg, err := ini.Load(path)
    if err != nil {
        return nil, fmt.Errorf("load config: %w", err)
    }

    cfg := &AppConfig{}

    sf := iniCfg.Section("SNOWFLAKE")
    cfg.Snowflake = SnowflakeConfig{
        Account:    sf.Key("account").String(),
        User:       sf.Key("user").String(),
        PrivateKey: sf.Key("private_key_path").String(),
        Role:       sf.Key("role").String(),
        Warehouse:  sf.Key("warehouse").String(),
        Database:   sf.Key("database").String(),
        Schema:     sf.Key("schema").String(),
    }

    sy := iniCfg.Section("SYBASE")
    cfg.Sybase = SybaseConfig{
        Driver: sy.Key("driver").String(),
        DSN:    sy.Key("dsn").String(),
    }

    st := iniCfg.Section("STATIC")
    tables := st.Key("tables").Strings(",")
    // trim spaces and normalize
    for i := range tables {
        tables[i] = strings.TrimSpace(tables[i])
    }

    cfg.Static = StaticConfig{
        Tables:               tables,
        RecycleDate:          st.Key("recycle_date").String(),
        RangeStart:           st.Key("range_start").String(),
        RangeEnd:             st.Key("range_end").String(),
        DataFilePath:         st.Key("data_file_path").String(),
        LandingFilePath:      st.Key("landing_file_path").String(),
        LogPath:              st.Key("log_file_path").String(),
        SchemaWritingDir:     st.Key("schema_writing_dir").String(),
        ReconWritingDir:      st.Key("recon_writing_dir").String(),
        XMLTemplatePath:      st.Key("xml_template_path").MustString("template.xml"),
        FieldSeparatorBinary: st.Key("field_separator_binary").String(),
        LineSeparatorBinary:  st.Key("line_separator_binary").String(),
    }

    out := iniCfg.Section("OUTPUT")
    cfg.Output = OutputConfig{
        NullString:         out.Key("null_string").MustString("\\N"),
        EscapeSequence:     out.Key("escape_sequence").MustString("\\"),
        NewlineReplacement: out.Key("newline_replacement").String(),
        BooleanAsInt:       out.Key("boolean_as_int").MustBool(true),
        DateFormat:         out.Key("date_format").MustString("YYYY-MM-DD"),
        TimestampFormat:    out.Key("timestamp_format").MustString("YYYY-MM-DD HH24:MI:SS.FF6"),
    }

    c := iniCfg.Section("CONSTANT")
    cfg.Constant = ConstantConfig{
        LogFileName: c.Key("log_file_name").MustString("export_tool.log"),
    }

    // expand relative paths relative to config file directory
    cfgDir := filepath.Dir(path)
    if !filepath.IsAbs(cfg.Static.DataFilePath) {
        cfg.Static.DataFilePath = filepath.Join(cfgDir, cfg.Static.DataFilePath)
    }
    if !filepath.IsAbs(cfg.Static.LandingFilePath) {
        cfg.Static.LandingFilePath = filepath.Join(cfgDir, cfg.Static.LandingFilePath)
    }
    if !filepath.IsAbs(cfg.Static.SchemaWritingDir) {
        cfg.Static.SchemaWritingDir = filepath.Join(cfgDir, cfg.Static.SchemaWritingDir)
    }
    if !filepath.IsAbs(cfg.Static.ReconWritingDir) {
        cfg.Static.ReconWritingDir = filepath.Join(cfgDir, cfg.Static.ReconWritingDir)
    }
    if !filepath.IsAbs(cfg.Snowflake.PrivateKey) {
        cfg.Snowflake.PrivateKey = filepath.Join(cfgDir, cfg.Snowflake.PrivateKey)
    }

    return cfg, nil
}
