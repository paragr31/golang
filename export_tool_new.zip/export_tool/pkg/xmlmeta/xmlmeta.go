package xmlmeta

import (
    "io/ioutil"
    "os"
    "text/template"
	"github.com/sirupsen/logrus"
)


var log *logrus.Logger

func SetLogger(l *logrus.Logger) {
    log = l
}

type XMLMeta struct {
    FileName       string
    SHA256         string
    FileSize       int64
    Rows           int64
    GzipMembers    int
    SchemaFilePath string
    ReconFilePath  string
    RecycleDate    string
    RangeStart     string
    RangeEnd       string
}

func Render(tplPath, outPath string, meta XMLMeta) error {
    b, err := ioutil.ReadFile(tplPath)
    if err != nil {
        return err
    }
    tpl, err := template.New("xmltpl").Parse(string(b))
    if err != nil {
        return err
    }
    f, err := os.Create(outPath)
    if err != nil {
        return err
    }
    defer f.Close()
    return tpl.Execute(f, meta)
}
