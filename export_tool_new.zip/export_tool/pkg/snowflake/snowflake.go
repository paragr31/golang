package snowflake

import (
    "crypto/rsa"
    "crypto/x509"
    "encoding/pem"
    "errors"
    "io/ioutil"
    "database/sql"

    gosnowflake "github.com/snowflakedb/gosnowflake"
	"github.com/sirupsen/logrus"
)

var log *logrus.Logger

func SetLogger(l *logrus.Logger) {
    log = l
}

func LoadPrivateKey(path string) (*rsa.PrivateKey, error) {
    b, err := ioutil.ReadFile(path)
    if err != nil {
        return nil, err
    }
    block, _ := pem.Decode(b)
    if block == nil {
        return nil, errors.New("invalid PEM block")
    }
    if k, err := x509.ParsePKCS8PrivateKey(block.Bytes); err == nil {
        if rsaKey, ok := k.(*rsa.PrivateKey); ok {
            return rsaKey, nil
        }
    }
    if k, err := x509.ParsePKCS1PrivateKey(block.Bytes); err == nil {
        return k, nil
    }
    return nil, errors.New("unsupported private key format")
}

func Connect(account, user, role, warehouse, database string, priv *rsa.PrivateKey) (*sql.DB, error) {
    cfg := gosnowflake.Config{
        Account:       account,
        User:          user,
        Role:          role,
        Warehouse:     warehouse,
        Database:      database,
        Authenticator: gosnowflake.AuthTypeJwt,
        PrivateKey:    priv,
    }
    dsn, err := gosnowflake.DSN(&cfg)
    if err != nil {
        return nil, err
    }
    return sql.Open("snowflake", dsn)
}
