package sybaseiq

import (
    "database/sql"
    "fmt"
    "os"
	"github.com/sirupsen/logrus"
)

var log *logrus.Logger

func SetLogger(l *logrus.Logger) {
    log = l
}

type ColumnMeta struct {
    Name string
    Type string
    Ord  int
}

func Connect(driver, dsn string) (*sql.DB, error) {
    // IMPORTANT: ensure you have the appropriate Sybase driver installed and imported in your project.
    return sql.Open(driver, dsn)
}

func GetTableColumns(db *sql.DB, schema, table string) ([]ColumnMeta, error) {
    q := `SELECT COLUMN_NAME, DATA_TYPE, ORDINAL_POSITION FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? ORDER BY ORDINAL_POSITION`
    rows, err := db.Query(q, schema, table)
    if err != nil {
        return nil, err
    }
    defer rows.Close()
    cols := []ColumnMeta{}
    for rows.Next() {
        var name, dtype string
        var ord int
        if err := rows.Scan(&name, &dtype, &ord); err != nil {
            return nil, err
        }
        cols = append(cols, ColumnMeta{Name: name, Type: dtype, Ord: ord})
    }
    return cols, nil
}

func WriteSchemaFile(path string, cols []ColumnMeta) error {
    f, err := os.Create(path)
    if err != nil {
        return err
    }
    defer f.Close()
    for _, c := range cols {
        _, _ = f.WriteString(fmt.Sprintf("%d,%s,%s\n", c.Ord, c.Name, c.Type))
    }
    return nil
}

func BuildSnowflakeSelect(cols []ColumnMeta, cfg *config.AppConfig) []string {
    // placeholder - implemented in main for simplicity or move formatting logic here as needed
    return nil
}
