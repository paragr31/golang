package writer

import (
    "archive/tar"
    "compress/gzip"
    "context"
    "crypto/sha256"
    "database/sql"
    "fmt"
    "io"
    "io/ioutil"
    "os"
    "path/filepath"
    "strings"
    "time"
	"github.com/sirupsen/logrus"
)

var log *logrus.Logger

func SetLogger(l *logrus.Logger) {
    log = l
}

func StreamQueryToGzip(ctx context.Context, db *sql.DB, query, outPath, fieldSep, lineSep, nullString string) (rows int64, sha string, size int64, err error) {
    rowsData, err := db.QueryContext(ctx, query)
    if err != nil {
        return 0, "", 0, err
    }
    defer rowsData.Close()

    cols, _ := rowsData.Columns()
    colCount := len(cols)

    _ = os.MkdirAll(filepath.Dir(outPath), 0o755)
    fout, err := os.Create(outPath)
    if err != nil {
        return 0, "", 0, err
    }
    gw := gzip.NewWriter(fout)
    defer func() {
        gw.Close()
        fout.Close()
    }()

    vals := make([]interface{}, colCount)
    for i := range vals {
        var v interface{}
        vals[i] = &v
    }

    rowCount := int64(0)
    for rowsData.Next() {
        if err := rowsData.Scan(vals...); err != nil {
            return rowCount, "", 0, err
        }
        fields := make([]string, colCount)
        for i := 0; i < colCount; i++ {
            raw := *(vals[i].(*interface{}))
            if raw == nil {
                fields[i] = nullString
                continue
            }
            switch v := raw.(type) {
            case []byte:
                fields[i] = string(v)
            case string:
                fields[i] = v
            case time.Time:
                fields[i] = v.Format(time.RFC3339)
            default:
                fields[i] = fmt.Sprintf("%v", v)
            }
        }
        line := strings.Join(fields, fieldSep) + lineSep
        if _, err := gw.Write([]byte(line)); err != nil {
            return rowCount, "", 0, err
        }
        rowCount++
    }

    if err := rowsData.Err(); err != nil {
        return rowCount, "", 0, err
    }

    if err := gw.Close(); err != nil {
        return rowCount, "", 0, err
    }
    if err := fout.Close(); err != nil {
        return rowCount, "", 0, err
    }

    // compute sha and size
    st, err := os.Stat(outPath)
    if err != nil {
        return rowCount, 0, 0, err
    }
    size = st.Size()

    f, err := os.Open(outPath)
    if err != nil {
        return rowCount, "", 0, err
    }
    defer f.Close()
    h := sha256.New()
    if _, err := io.Copy(h, f); err != nil {
        return rowCount, "", 0, err
    }
    sha = fmt.Sprintf("%x", h.Sum(nil))
    return rowCount, sha, size, nil
}

func CreateTarGz(srcDir, tarGzPath string) (sha string, size int64, err error) {
    if err := os.MkdirAll(filepath.Dir(tarGzPath), 0o755); err != nil {
        return "", 0, err
    }
    outFile, err := os.Create(tarGzPath)
    if err != nil {
        return "", 0, fmt.Errorf("create tar.gz: %w", err)
    }
    defer outFile.Close()

    gzWriter := gzip.NewWriter(outFile)
    defer gzWriter.Close()

    tarWriter := tar.NewWriter(gzWriter)
    defer tarWriter.Close()

    err = filepath.Walk(srcDir, func(path string, info os.FileInfo, err error) error {
        if err != nil {
            return err
        }
        if info.IsDir() {
            return nil
        }
        // only include .bcp and .xml and .schema files
        if !strings.HasSuffix(path, ".bcp") && !strings.HasSuffix(path, ".xml") && !strings.HasSuffix(path, ".schema") {
            return nil
        }
        file, err := os.Open(path)
        if err != nil {
            return err
        }
        defer file.Close()

        header, err := tar.FileInfoHeader(info, "")
        if err != nil {
            return err
        }
        relPath, err := filepath.Rel(srcDir, path)
        if err != nil {
            return err
        }
        header.Name = relPath
        if err := tarWriter.WriteHeader(header); err != nil {
            return err
        }
        if _, err := io.Copy(tarWriter, file); err != nil {
            return err
        }
        return nil
    })
    if err != nil {
        return "", 0, fmt.Errorf("walk dir: %w", err)
    }

    tarWriter.Close()
    gzWriter.Close()
    outFile.Close()

    st, err := os.Stat(tarGzPath)
    if err != nil {
        return "", 0, err
    }
    size = st.Size()
    f, err := os.Open(tarGzPath)
    if err != nil {
        return "", 0, err
    }
    defer f.Close()
    h := sha256.New()
    if _, err := io.Copy(h, f); err != nil {
        return "", 0, err
    }
    sha = fmt.Sprintf("%x", h.Sum(nil))
    return sha, size, nil
}

func MoveFile(src, dst string) error {
    if err := os.Rename(src, dst); err == nil {
        return nil
    }
    sf, err := os.Open(src)
    if err != nil {
        return err
    }
    defer sf.Close()
    df, err := os.Create(dst)
    if err != nil {
        return err
    }
    defer df.Close()
    if _, err := io.Copy(df, sf); err != nil {
        return err
    }
    if err := sf.Close(); err != nil {
        return err
    }
    return os.Remove(src)
}
